const arterraWines = [
  {
    name: "Reserve",
    wineType: "red",
    dry: true,
    sweet: false,
    flavorProfile: ["full bodied"],
    imageLink:
      "https://images.pexels.com/photos/268858/pexels-photo-268858.jpeg?cs=srgb&dl=clean-clear-close-up-268858.jpg&fm=jpg",
    fruitFlavorProfile: ["black fruit"],
    winery: "Arterra Wines",
    city: "Delaplane",
    state: "VA",
    tags: ["cabernet sauvignon", "tannat", "petit verdot", "cabernet franc"],
    foodPair: []
  },
  {
    name: "Reserve",
    wineType: "red",
    dry: true,
    sweet: false,
    flavorProfile: ["full bodied"],
    imageLink:
      "https://images.pexels.com/photos/268858/pexels-photo-268858.jpeg?cs=srgb&dl=clean-clear-close-up-268858.jpg&fm=jpg",
    fruitFlavorProfile: ["black fruit"],
    winery: "Arterra Wines",
    city: "Delaplane",
    state: "VA",
    tags: ["cabernet sauvignon", "tannat", "petit verdot", "cabernet franc"],
    foodPair: []
  }
];

export default arterraWines;
