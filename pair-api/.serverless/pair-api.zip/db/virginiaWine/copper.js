const copper = [
  {
    name: "Noche",
    wineType: "red",
    dry: false,
    sweet: true,
    imageLink:
      "https://images.pexels.com/photos/1083617/pexels-photo-1083617.jpeg?cs=srgb&dl=abstract-acrylic-art-1083617.jpg&fm=jpg",
    flavorProfile: ["chocolate", "dark chocolate"],
    fruitFlavorProfile: ["plum", "black fruit"],
    winery: "Copper Vineyards",
    city: "Louisa",
    state: "VA",
    tags: ["port"],
    foodPair: [
      "bittersweet chocolate",
      "coffee ice cream",
      "almond tart",
      "apple tart",
      "creme brulée",
      "white cheddar",
      "manchego cheese",
      "hard cheeses"
    ]
    /**TODO:
     * add cheese to foodPair
     */
  },
  {
    name: "Noche",
    wineType: "red",
    dry: false,
    sweet: true,
    imageLink:
      "https://images.pexels.com/photos/1083617/pexels-photo-1083617.jpeg?cs=srgb&dl=abstract-acrylic-art-1083617.jpg&fm=jpg",
    flavorProfile: ["chocolate", "dark chocolate"],
    fruitFlavorProfile: ["plum", "black fruit"],
    winery: "Copper Vineyards",
    city: "Louisa",
    state: "VA",
    tags: ["port"],
    foodPair: [
      "bittersweet chocolate",
      "coffee ice cream",
      "almond tart",
      "apple tart",
      "creme brulée",
      "white cheddar",
      "manchego cheese",
      "hard cheeses"
    ]
    /**TODO:
     * add cheese to foodPair
     */
  }
];

export default copper;
